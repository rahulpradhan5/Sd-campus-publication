
// nev show
$("#mobile-nev").on('click',function(){
   $("#mobile-actual-nav").css("display","flex");
})

$("#cancel").on('click',function(){

   $("#mobile-actual-nav").css("display","none");
})


$("#more").on('click',function(){
   $("#more").css('display','none');
   $("#morerev").css('display','initial');
   $(".subnev").css('display','flex')
})
$("#morerev").on('click',function(){
   $("#more").css('display','initial');
   $("#morerev").css('display','none');
   $(".subnev").css('display','none')
})

$("#mobMore").on('click' ,function(){
   $("#mobMore").css('display','none');
$("#mobRev").css('display','initial');
$("#moreDivmob").css('display','flex');
})
$("#mobRev").on('click' ,function(){
   $("#mobMore").css('display','initial');
$("#mobRev").css('display','none');
$("#moreDivmob").css('display','none');
})

// popup-open
function popupOpen(){
   $(".popup").css("display","flex");
}
function popupClose(){
   $(".popup").css("display","none");
}

function examDropopen(id){
$("#examdropdown"+id).css("display","none");
$("#drop"+id).css("display","flex");
$("#examdropdownclose"+id).css("display","block");
}
function examDropclose(id){
   
   $("#drop"+id).css("display","none");
   $("#examdropdown"+id).css("display","flex");
   $("#examdropdownclose"+id).css("display","none");
   }

   function openDiv(clickDiv,openDiv){
      $(clickDiv).css("display","none");
      $(openDiv).css('display',"block");
   }

   function closeDiv(clickDiv,openDiv){
      $(clickDiv).css("display","none");
      $(openDiv).css('display',"block");
   }

   function faqOpen(opener,closer,opendiv){
      $(opener).css("display","none")
      $(closer).css("display","initial")
      $(opendiv).css("display","block")
   }
   function faqClose(opener,closer,opendiv){
      $(opener).css("display","initial")
      $(closer).css("display","none")
      $(opendiv).css("display","none")
   }

var swiper1 = new Swiper('.courses-div-ajuster', {
    breakpoints: {
 
       1000: {
          slidesPerView: 3,
       },
       // when window width is >= 992px (desktop size)
       800: {
          slidesPerView: 1,
         
       },
       500: {
          slidesPerView: 1,
       },
    },
    spaceBetween: 20,
 
    navigation: {
       nextEl: '.right-arrow',
       prevEl: '.left-arrow',
    },
 });

//  var swiper2 = new Swiper('.pjbsc', {
//    breakpoints: {

//       1000: {
//          slidesPerView: 4,
//       },
//       // when window width is >= 992px (desktop size)
//       800: {
//          slidesPerView: 3,
        
//       },
//       500: {
//          slidesPerView: 2,
//       },
//    },
//    spaceBetween: 20,

//    navigation: {
//       nextEl: '.popularexamnext',
//       prevEl: '.popularexamprev',
//    },
// });

var swiper3 = new Swiper('.course-div-adjuster-exam', {
   breakpoints: {

      1100: {
         slidesPerView: 3,
      },
      // when window width is >= 992px (desktop size)
      800: {
         slidesPerView: 2,
        
      },
      500: {
         slidesPerView: 1,
      },
   },
   spaceBetween: 20,

   navigation: {
      nextEl: '.right-arrow',
      prevEl: '.left-arrow',
   },
});


//    mobile nev close open

function tarnsDrop(id){
   $("#drop-open"+id).css("display","none");
   $("#drop-tab"+id).css("display","block");
}
function tarnsCLose(id){
   $("#drop-open"+id).css("display","flex");
   $("#drop-tab"+id).css("display","none");
}