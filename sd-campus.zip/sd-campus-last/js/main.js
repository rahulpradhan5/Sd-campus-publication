function showDiv(showd){
    $(".float-div").css("display","none !important")
    document.getElementById(showd).classList.toggle("flex-imp")
}


// mobile nav customiser
function openDrop(imageID,opendiv){
    if( $("#"+imageID).css("rotate") == "180deg" ||  $("#"+opendiv).css("display") == "flex"){
        $("#"+imageID).css("rotate","0deg");
        $("#"+opendiv).css("display","none");
    }else if($("#"+opendiv).css("display") == "none"){
        $("#"+imageID).css("rotate","180deg");
        $("#"+opendiv).css("display","flex");
    }
    else{
        $("#"+imageID).css("rotate","180deg");
        $("#"+opendiv).css("display","flex ");
    }
}
// filters menu

$("#filters-menu").on('click',function(){
        $("#filters").css("display","flex");

})
$("#ctaeclose").on('click',function(){
    $("#filters").css("display","none");

})

$("#cancel").on('click',function(){
    $(".mobile-nav").css("display","none")
})
$("#menu").on('click',function(){
    $(".mobile-nav").css("display","flex")
})