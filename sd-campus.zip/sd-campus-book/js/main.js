$(".dropdown").on('click',function(){
    if($(".profile-dropdown").css("display") == "flex"){
        $(".profile-dropdown").css("display","none")
    }else if($(".profile-dropdown").css("display") == "none"){
        $(".profile-dropdown").css("display","flex")
    }
})


// toggle
const toggleBtn = document.getElementById("toggle-btn");

toggleBtn.addEventListener("click", function() {
    this.classList.toggle("active");
    document.getElementById("mobile-nav").classList.toggle("flex-imp")
});

// fliter
$("#filter").on('click',function(){
    document.getElementById("filter-div").classList.toggle("flex-imp");
})